# Windbrook Portal — Phase 19: REPLACE Files (Final Fix)

This phase is different from previous phases. Instead of describing changes,
**four complete files are provided in `/files-to-drop-in/`**. Replace the
existing files with these. Do not interpret. Do not "improve". Drop them in.

After dropping in, wire them following the instructions below, restart, and
verify the three issues are fixed.

---

## What's in the drop-in folder

```
files-to-drop-in/
├── src/
│   ├── lib/canva.ts           ← REPLACES the existing canva.ts entirely
│   ├── routes/canva.ts        ← REPLACES the existing canva routes
│   ├── routes/layout.ts       ← REPLACES the layout persistence route
│   └── reports/tcc/render.tsx ← REPLACES the TCC renderer entirely
└── public/
    └── js/layout-editor.js    ← REPLACES the existing layout editor
```

These files were written based on:
- The official Canva Connect documentation at https://www.canva.dev/docs/connect/
  including the Authentication and Quickstart pages — read with proper attention
  this round
- A correct understanding that bubbles in the reference template are ELLIPSES
  (140×110) not circles
- Diagnostic logging at every failure point so the next failure is debuggable

## Fixes vs prior versions

### Canva (`src/lib/canva.ts`)

1. `code_challenge_method` is `"s256"` (lowercase). Canva's official docs and
   Authorization URL generator use lowercase. Previous versions used `"S256"`
   uppercase, which Canva rejects.
2. Token exchange uses HTTP Basic auth header (Base64 of `client_id:client_secret`),
   not body-based credentials. Required by Canva docs.
3. `getCanvaConfig()` is the single source of truth for redirect_uri.
   It strips trailing slashes and rejects `localhost`.
4. PKCE state is stored in-memory (Map) keyed by state value; expires in 10 min.
   State is verified on callback to prevent CSRF.
5. Verbose logging on every step. The exact redirect_uri being sent is printed
   to the server console at every authorize call.

### TCC renderer (`src/reports/tcc/render.tsx`)

1. Bubbles are `<ellipse>` 156×120 (rx=78, ry=60), not circles.
2. Text positioning is hardcoded — not computed — so it cannot drift.
3. Account names auto-wrap to 2 lines if longer than 13 chars.
4. Empty slots are rendered as `<ellipse class="slot">` with proper data
   attributes for the drag system to find them.
5. Canvas is 1100×850 (larger than US Letter) so slots have breathing room.

### Layout editor (`public/js/layout-editor.js`)

1. Logs everything: page load, init, button click, drag start, drag move,
   slot search results, drag end. Open DevTools console to see exactly what's
   happening.
2. `findNearestSlot` falls back to ALL slots if section-specific lookup fails,
   AND warns about the section mismatch in console.
3. Always returns the nearest slot regardless of distance — bubbles always
   land somewhere reasonable.
4. Uses `setPointerCapture` so pointermove fires reliably during drag.

## What you (Claude Code) must do

### Step 1: Replace the files

```bash
# From the project root
cp files-to-drop-in/src/lib/canva.ts                src/lib/canva.ts
cp files-to-drop-in/src/routes/canva.ts             src/routes/canva.ts
cp files-to-drop-in/src/routes/layout.ts            src/routes/layout.ts
cp files-to-drop-in/src/reports/tcc/render.tsx      src/reports/tcc/render.tsx
cp files-to-drop-in/public/js/layout-editor.js      public/js/layout-editor.js
```

If file paths differ in the existing project (e.g. `src/lib/canva-client.ts`),
adapt to the actual location. Same exports, same function signatures.

### Step 2: Verify the imports/wiring

In `src/app.ts` (or wherever Hono routes are mounted):

```ts
import { canvaRoutes } from './routes/canva';
import { layoutRoutes } from './routes/layout';

app.route('/api/canva', canvaRoutes);
app.route('/reports', layoutRoutes);
```

In the layout-persistence route (`src/routes/layout.ts`), uncomment the DB
section and wire to your actual `db` and schema imports. The route currently
has the DB block commented out so it doesn't break compilation if your imports
differ — get this working with your actual schema.

In `src/routes/canva.ts`, uncomment the `saveCanvaTokens` and `clearCanvaTokens`
calls and wire to your DB query module. These persist the tokens after a
successful exchange.

### Step 3: Verify the report detail page includes the layout-editor script

In the report detail page template (the one that renders the SVG), make sure
this script tag is present at the bottom of the body:

```html
<script src="/js/layout-editor.js" defer></script>
```

And that the report SVG has `class="report-svg"` and `data-report-id="..."`.
Without these, the layout editor cannot find the SVG.

### Step 4: Verify the toggle button has the right ID

The "Edit layout" button must have `id="edit-layout-toggle"`. Without this ID,
the layout editor cannot wire up the toggle behavior.

### Step 5: Update CLAUDE.md

Add or update the "Canva Setup" section with these CORRECTED instructions:

```markdown
## Canva Connect Integration Setup

### One-time portal configuration

1. Visit https://www.canva.com/developers/integrations
2. Click into your "educated_freedom" integration (or create a new one)
3. Configuration → Generate secret → save to `.env` as CANVA_CLIENT_SECRET
4. Configuration → Client ID → save to `.env` as CANVA_CLIENT_ID
5. Scopes → enable: profile:read, asset:read, asset:write, design:meta:read,
   design:content:read, design:content:write, brandtemplate:meta:read,
   brandtemplate:content:read
6. Authentication → Authorized redirects → URL 1 (default):
   `http://127.0.0.1:3000/api/canva/callback`
   - NOT localhost — Canva rejects `localhost`
   - NO trailing slash
7. Save

### `.env` values

```
CANVA_CLIENT_ID=<from step 4>
CANVA_CLIENT_SECRET=<from step 3>
CANVA_REDIRECT_URI=http://127.0.0.1:3000/api/canva/callback
```

### Access the portal at the right URL

Always use http://127.0.0.1:3000 for local development. Canva requires the
browser to send the redirect URI byte-identical to the registered one — using
http://localhost:3000 will cause OAuth to fail with "redirect_uri mismatch".
```

### Step 6: Restart and verify

```bash
pnpm dev
```

Watch the startup log. It should show the redirect URI and confirm 127.0.0.1
is reachable.

Open http://127.0.0.1:3000 in the browser. Log in.

## Verification checklist

After these changes are in place, the user can verify:

### A. TCC bubbles

1. Open any TCC report (e.g., Cole Household January 21 2026)
2. Bubbles should be ELLIPSES (wider than tall), not circles
3. All text should fit comfortably inside each bubble with breathing room
4. Long account names ("Cash Management", "Schwab Brokerage") should wrap to
   two lines, not truncate with "..."

### B. Edit Layout drag

1. Open a TCC report
2. Open browser DevTools → Console
3. Page load should print:
   ```
   [layout-editor] v2 loaded at <date>
   [layout-editor] init()
   [layout-editor]   svg[0]: bubbles=N, slots=M
   [layout-editor]   sample bubble: { ... }
   [layout-editor]   sample slot: { ... }
   [layout-editor] Toggle wired
   ```
4. Click "Edit layout" button → should see `[layout-editor] enableEditMode`
5. Click and hold a bubble → should see `[layout-editor] pointer down: account=..., section=...`
6. Drag and release on an empty slot → should see persist log and reload
7. After reload, the bubble is in the new position

### C. Canva connect

1. Click "Connect Canva" → server console should print the diagnostic block
   showing the redirect_uri being sent
2. Browser navigates to Canva's authorize page
3. Approve scopes
4. Canva redirects to /api/canva/callback
5. Server console prints "tokens obtained, expires_in=..."
6. Browser lands on /dashboard?canva=connected

If step 4 fails with "redirect_uri" error: open the Canva developer portal,
go to Authentication, and verify the registered URL matches the one printed
in the server log byte-for-byte.

If step 5 fails: the error page in the browser will explain what failed and
what to do.

## What if any of this still doesn't work

Each of the three components has heavy logging. Send back:

- For TCC bubbles: a screenshot of `?debug=1` on a TCC report
- For drag: the entire DevTools console output
- For Canva: the entire `[canva:authorize]` and `[canva:callback]` blocks from
  the server terminal

These give complete diagnosis without further guessing. Whatever the next
issue is, there will be data to act on.
