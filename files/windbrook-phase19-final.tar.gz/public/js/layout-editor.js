// public/js/layout-editor.js
//
// Drag-and-drop bubble repositioning for SVG reports.
//
// Self-diagnostic: logs every step. If anything fails, the cause is in the console.
//
// Required DOM contract (the SVG renderer must produce this):
//   <svg class="report-svg" data-report-id="..." data-report-type="SACS|TCC">
//     <g class="bubble"
//        data-account-id="..."
//        data-slot-id="..."
//        data-section="retirement-left|retirement-right|nonret-left|nonret-right"
//        data-cx="123" data-cy="456">
//       ...
//     </g>
//     <ellipse class="slot"
//              data-slot-id="..."
//              data-section="..."
//              data-cx="..." data-cy="..."
//              cx="..." cy="..." rx="70" ry="55"
//              fill="none" stroke="..." />
//   </svg>
//
// Toggle button must have id="edit-layout-toggle".

(function () {
  'use strict';

  const SNAP_DISTANCE_PX = 999; // effectively unlimited within a section

  let editMode = false;
  let dragging = null;

  console.log('[layout-editor] v2 loaded at ' + new Date().toISOString());

  // =========================================================================
  // INIT
  // =========================================================================

  function init() {
    console.log('[layout-editor] init()');

    const toggleBtn = document.getElementById('edit-layout-toggle');
    if (!toggleBtn) {
      console.warn('[layout-editor] No #edit-layout-toggle found — drag will not be activatable');
      return;
    }

    const svgs = document.querySelectorAll('svg.report-svg');
    console.log('[layout-editor] Found ' + svgs.length + ' svg.report-svg elements');

    if (svgs.length === 0) {
      console.warn('[layout-editor] No SVG report containers found. Check that the report SVG has class="report-svg"');
      return;
    }

    svgs.forEach((svg, idx) => {
      const bubbles = svg.querySelectorAll('.bubble');
      const slots = svg.querySelectorAll('.slot');
      console.log('[layout-editor]   svg[' + idx + ']: bubbles=' + bubbles.length + ', slots=' + slots.length);

      if (bubbles.length === 0) {
        console.warn('[layout-editor]   ⚠ SVG has no .bubble elements');
      }
      if (slots.length === 0) {
        console.warn('[layout-editor]   ⚠ SVG has no .slot elements — drop will not work!');
        console.warn('[layout-editor]   The renderer must output empty slots as <ellipse class="slot"> elements');
      }

      // Sample first bubble + slot for sanity check
      if (bubbles[0]) {
        console.log('[layout-editor]   sample bubble:', {
          'data-account-id': bubbles[0].getAttribute('data-account-id'),
          'data-slot-id': bubbles[0].getAttribute('data-slot-id'),
          'data-section': bubbles[0].getAttribute('data-section'),
          'data-cx': bubbles[0].getAttribute('data-cx'),
          'data-cy': bubbles[0].getAttribute('data-cy'),
        });
      }
      if (slots[0]) {
        console.log('[layout-editor]   sample slot:', {
          'data-slot-id': slots[0].getAttribute('data-slot-id'),
          'data-section': slots[0].getAttribute('data-section'),
          'data-cx': slots[0].getAttribute('data-cx'),
          'data-cy': slots[0].getAttribute('data-cy'),
        });
      }
    });

    toggleBtn.addEventListener('click', onToggleClick);
    console.log('[layout-editor] Toggle wired');
  }

  function onToggleClick(evt) {
    evt.preventDefault();
    if (editMode) {
      disableEditMode();
    } else {
      enableEditMode();
    }
  }

  // =========================================================================
  // EDIT MODE
  // =========================================================================

  function enableEditMode() {
    console.log('[layout-editor] enableEditMode');
    editMode = true;
    const toggleBtn = document.getElementById('edit-layout-toggle');
    if (toggleBtn) {
      toggleBtn.textContent = 'Done editing';
      toggleBtn.classList.add('active');
    }

    document.querySelectorAll('svg.report-svg').forEach(svg => {
      svg.classList.add('edit-mode');
      svg.querySelectorAll('.bubble').forEach(bubble => {
        bubble.style.cursor = 'grab';
        bubble.addEventListener('pointerdown', onPointerDown);
      });
    });
  }

  function disableEditMode() {
    console.log('[layout-editor] disableEditMode');
    editMode = false;
    const toggleBtn = document.getElementById('edit-layout-toggle');
    if (toggleBtn) {
      toggleBtn.textContent = 'Edit layout';
      toggleBtn.classList.remove('active');
    }

    document.querySelectorAll('svg.report-svg').forEach(svg => {
      svg.classList.remove('edit-mode', 'drag-active');
      svg.querySelectorAll('.bubble').forEach(bubble => {
        bubble.style.cursor = '';
        bubble.removeEventListener('pointerdown', onPointerDown);
      });
    });
  }

  // =========================================================================
  // POINTER HANDLERS
  // =========================================================================

  function onPointerDown(evt) {
    if (!editMode) return;
    evt.preventDefault();
    evt.stopPropagation();

    const bubble = evt.currentTarget;
    const svg = bubble.ownerSVGElement;
    const accountId = bubble.getAttribute('data-account-id');
    const sectionType = bubble.getAttribute('data-section');

    console.log('[layout-editor] pointer down: account=' + accountId + ', section=' + sectionType);

    if (!sectionType) {
      console.error('[layout-editor] Bubble has no data-section attribute — cannot drag');
      return;
    }

    const startPt = svgPointFromEvent(svg, evt);
    const cx = parseFloat(bubble.getAttribute('data-cx') || '0');
    const cy = parseFloat(bubble.getAttribute('data-cy') || '0');

    dragging = {
      element: bubble,
      svg: svg,
      sectionType: sectionType,
      accountId: accountId,
      startPtX: startPt.x,
      startPtY: startPt.y,
      originCX: cx,
      originCY: cy,
      currentX: cx,
      currentY: cy,
    };

    bubble.style.cursor = 'grabbing';
    svg.classList.add('drag-active');
    bubble.setPointerCapture(evt.pointerId);

    bubble.addEventListener('pointermove', onPointerMove);
    bubble.addEventListener('pointerup', onPointerUp);
    bubble.addEventListener('pointercancel', onPointerCancel);
    document.addEventListener('keydown', onKeyDown);
  }

  function onPointerMove(evt) {
    if (!dragging) return;
    const pt = svgPointFromEvent(dragging.svg, evt);
    const dx = pt.x - dragging.startPtX;
    const dy = pt.y - dragging.startPtY;

    dragging.currentX = dragging.originCX + dx;
    dragging.currentY = dragging.originCY + dy;

    dragging.element.setAttribute('transform', 'translate(' + dx + ',' + dy + ')');

    const slot = findNearestSlot(
      dragging.svg,
      dragging.currentX,
      dragging.currentY,
      dragging.sectionType
    );

    dragging.svg.querySelectorAll('.slot.highlight').forEach(s =>
      s.classList.remove('highlight')
    );
    if (slot) slot.classList.add('highlight');
  }

  function onPointerUp(evt) {
    if (!dragging) return;
    const slot = findNearestSlot(
      dragging.svg,
      dragging.currentX,
      dragging.currentY,
      dragging.sectionType
    );

    if (slot) {
      const newSlotId = slot.getAttribute('data-slot-id');
      console.log('[layout-editor] dropping on slot ' + newSlotId);
      persistAndReload(dragging.accountId, newSlotId);
    } else {
      console.log('[layout-editor] no slot found — snapping back to origin');
      dragging.element.setAttribute('transform', '');
    }

    cleanupDrag();
  }

  function onPointerCancel() {
    if (!dragging) return;
    console.log('[layout-editor] pointer cancel — snapping back');
    dragging.element.setAttribute('transform', '');
    cleanupDrag();
  }

  function onKeyDown(evt) {
    if (evt.key === 'Escape' && dragging) {
      console.log('[layout-editor] escape pressed — cancelling drag');
      dragging.element.setAttribute('transform', '');
      cleanupDrag();
    }
  }

  function cleanupDrag() {
    if (!dragging) return;
    dragging.element.style.cursor = 'grab';
    dragging.svg.classList.remove('drag-active');
    dragging.svg.querySelectorAll('.slot.highlight').forEach(s =>
      s.classList.remove('highlight')
    );
    dragging.element.removeEventListener('pointermove', onPointerMove);
    dragging.element.removeEventListener('pointerup', onPointerUp);
    dragging.element.removeEventListener('pointercancel', onPointerCancel);
    document.removeEventListener('keydown', onKeyDown);
    dragging = null;
  }

  // =========================================================================
  // PERSIST
  // =========================================================================

  function persistAndReload(accountId, slotId) {
    const svg = document.querySelector('svg.report-svg[data-report-id]');
    const reportId = svg ? svg.getAttribute('data-report-id') : null;
    if (!reportId) {
      console.error('[layout-editor] No data-report-id on SVG — cannot persist');
      if (dragging) dragging.element.setAttribute('transform', '');
      return;
    }

    console.log('[layout-editor] POST /reports/' + reportId + '/layout', { accountId, slotId });

    fetch('/reports/' + reportId + '/layout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ accountId, slotId }),
    })
      .then(res => {
        if (!res.ok) throw new Error('POST returned ' + res.status);
        console.log('[layout-editor] persist OK — reloading');
        location.reload();
      })
      .catch(err => {
        console.error('[layout-editor] persist FAILED:', err);
        if (dragging) dragging.element.setAttribute('transform', '');
        alert('Failed to save layout. The server route /reports/:id/layout may not be implemented. See console for details.');
      });
  }

  // =========================================================================
  // GEOMETRY
  // =========================================================================

  function svgPointFromEvent(svg, evt) {
    const pt = svg.createSVGPoint();
    pt.x = evt.clientX;
    pt.y = evt.clientY;
    return pt.matrixTransform(svg.getScreenCTM().inverse());
  }

  function findNearestSlot(svg, x, y, sectionType) {
    // Try section-specific slots first
    let slots = svg.querySelectorAll('.slot[data-section="' + sectionType + '"]');

    if (slots.length === 0) {
      console.warn(
        '[layout-editor] No slots with data-section="' + sectionType + '". ' +
        'Available sections: ' +
        Array.from(svg.querySelectorAll('.slot'))
          .map(s => s.getAttribute('data-section'))
          .filter((v, i, a) => a.indexOf(v) === i)
          .join(', ')
      );
      // Fall back: any slot in the SVG (drag still works, just less restrictive)
      slots = svg.querySelectorAll('.slot');
    }

    if (slots.length === 0) {
      console.error('[layout-editor] NO SLOTS in SVG. Check renderer outputs <ellipse class="slot">.');
      return null;
    }

    let nearest = null;
    let minDist = Infinity;
    slots.forEach(slot => {
      const sx = parseFloat(slot.getAttribute('data-cx') || '0');
      const sy = parseFloat(slot.getAttribute('data-cy') || '0');
      const dist = Math.hypot(x - sx, y - sy);
      if (dist < minDist) {
        minDist = dist;
        nearest = slot;
      }
    });

    return nearest; // always return nearest; no distance threshold
  }

  // =========================================================================
  // BOOT
  // =========================================================================

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
